# LinkTree
This is a bootstrap one page application devoloped for just sharing social links just replace with your
details.

To host you can use either<br>
<b>Github Pages: </b> https://pages.github.com
<br> or <br>
<b>Netlify: </b> https://netlify.com

# Change Photos
Line No: 5 This is favicon<br>
Line No: 48 This will be your photo

# Social Links
Line No: 58 to 67 replace # with your desire link

# Names
Replace (Your Name) with Your Name <br>
Replace (Your City) with Your City <br>
Replace (Your Country) with Your Country Name<br>

# Gmali
Line No: 74 replace (Your Mail) with your gmail without brackets 

## Contact Me
#### 👨‍💻 Irshad Ali<br>
#### 📝 phonerefer@gmail.com or hello@phonerefer.com<br>
#### 🌍 https://irshadali.codes

